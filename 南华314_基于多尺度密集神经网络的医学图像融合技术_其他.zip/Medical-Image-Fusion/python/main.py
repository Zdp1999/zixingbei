# Demo - train the DenseFuse network & use it to generate an image

from __future__ import print_function

import time

from train_recons import train_recons
from generate import generate
from utils import list_images
import os

# os.environ["CUDA_VISIBLE_DEVICES"] = "1"

# True for training phase
IS_TRAINING = False
# True for video sequences(frames)
IS_VIDEO = False
# True for RGB images
is_RGB = False
is_Gray = True


BATCH_SIZE = 2
EPOCHES = 50

SSIM_WEIGHTS = [50]
MODEL_SAVE_PATHS = [
    './models/densefuse_gray/multiScale_densefuse_epoch4_all_weight_1e0.ckpt',
    './models/densefuse_gray/multiScale_densefuse_epoch4_all_weight_1e1.ckpt',
    './models/densefuse_gray/multiScale_densefuse_epoch4_all_weight_1e2.ckpt',
    './models/densefuse_gray/multiScale_densefuse_epoch4_all_weight_1e3.ckpt',
]

# MODEL_SAVE_PATH = './models/deepfuse_dense_model_bs4_epoch2_relu_pLoss_noconv_test.ckpt'
# model_pre_path  = './models/deepfuse_dense_model_bs2_epoch2_relu_pLoss_noconv_NEW.ckpt'

# In testing process, 'model_pre_path' is set to None
# The "model_pre_path" in "main.py" is just a pre-train model and not necessary for training and testing. 
# It is set as None when you want to train your own model. 
# If you already train a model, you can set it as your model for initialize weights.
model_pre_path = None

def main():

    if IS_TRAINING:

        original_imgs_path = list_images('./train_patches/')
        validatioin_imgs_path = list_images('./validation1/')

        for ssim_weight, model_save_path in zip(SSIM_WEIGHTS, MODEL_SAVE_PATHS):
            print('\nBegin to train the network ...\n')
            train_recons(original_imgs_path, validatioin_imgs_path, model_save_path, model_pre_path, ssim_weight, EPOCHES, BATCH_SIZE, debug=True)

            print('\nSuccessfully! Done training...\n')
    else:
        if is_Gray:
            ssim_weight = SSIM_WEIGHTS[0]
            model_path = MODEL_SAVE_PATHS[0]
            print('\nBegin to generate pictures ...\n')
            path = './CT+MR/'
            path1 = path + 'CT/'
            path2 = path + 'MR1/'
            savepath = 'out2/'
            for i in range(9):
                index = i + 1
                CT_path = path1 + str(index) + 'A' + '.jpg'
                MR_path = path2 + str(index) + 'B' + '.jpg'
                generate(CT_path, MR_path, model_path, model_pre_path,
                         ssim_weight, index, is_Gray, 'addition', output_path=savepath)

            # ssim_weight = SSIM_WEIGHTS[0]
            # model_path = MODEL_SAVE_PATHS[0]
            # print('\nBegin to generate pictures ...\n')
            # path = './video/'
            # path1 = path + 'IR/'
            # path2 = path + 'VIS/'
            # savepath = 'video/'
            # for i in range(6):
            #     index = i + 1
            #     CT_path = path1 + 'IR' + str(index) + '.jpg'
            #     MR_path = path2 + 'VIS' + str(index) + '.jpg'
            #     generate(CT_path, MR_path, model_path, model_pre_path,
            #              ssim_weight, index, is_Gray, 'addition', output_path=savepath)
        else:
            ssim_weight = SSIM_WEIGHTS[2]
            model_path = MODEL_SAVE_PATHS[2]
            print('\nBegin to generate pictures ...\n')
            # path = 'images/IV_images/'
            #path1 = 'images/Medical_images/1/'
            #path2 = 'images/Medical_images/2/'
            path = './MRI+SPECT/'
            for i in range(1,16):
                #index = i + 1
                index = i
                num1 = 'A'
                num2 = 'B'
                # infrared = path + 'IR' + str(index) + '.png'
                # visible = path + 'VIS' + str(index) + '.png'

                # RGB images
                infrared = path + str(index) + str(num1) + '.jpg'
                visible = path + str(index) + str(num2) + '.jpg'

                # choose fusion layer
                #fusion_type = 'addition'
                fusion_type = 'l1'
                # for ssim_weight, model_path in zip(SSIM_WEIGHTS, MODEL_SAVE_PATHS):
                # 	output_save_path = 'outputs'
                output_save_path = 'out/MRI_SPECT/'
                generate(infrared, visible, model_path, model_pre_path,
                             ssim_weight, index, IS_VIDEO, is_RGB, type = fusion_type, output_path = output_save_path)

                #output_save_path = 'outputs'
                #generate(infrared, visible, model_path, model_pre_path,
                #		 ssim_weight, index, IS_VIDEO, is_RGB, type = fusion_type, output_path = output_save_path)


if __name__ == '__main__':
    main()

