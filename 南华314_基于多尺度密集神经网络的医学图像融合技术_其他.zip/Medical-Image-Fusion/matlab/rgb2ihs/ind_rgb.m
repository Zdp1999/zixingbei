clc;
clear all;
for num=16:30
  [X,map]=imread(strcat('./PET/',num2str(num),'.jpg'));  
  RGB=ind2rgb(X,map); 
  imwrite(RGB, strcat('./RGB/',num2str(num),'.jpg'));
%   imwrite(v1,strcat('',num2str(num),'.bmp'));
%   imwrite(v2,strcat('',num2str(num),'.bmp'));
  
end