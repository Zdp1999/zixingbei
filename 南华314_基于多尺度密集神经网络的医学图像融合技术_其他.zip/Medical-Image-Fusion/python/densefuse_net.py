# DenseFuse Network
# Encoder -> Addition/L1-norm -> Decoder

import tensorflow as tf
import torch
from encoder import Encoder
from decoder import Decoder
from fusion_addition import Strategy
import numpy as np
from Deconv import deconv_vis, deconv_ir
class DenseFuseNet(object):

    def __init__(self, model_pre_path):
        self.encoder = Encoder(model_pre_path)
        self.decoder = Decoder(model_pre_path)

    def transform_addition(self, img1, img2):
        # encode image
        enc_1 = self.encoder.encode(img1)
        enc_2 = self.encoder.encode(img2)
        target_features = Strategy(enc_1, enc_2)
        # target_features = enc_c
        self.target_features = target_features
        print('target_features:', target_features.shape)
        # decode target features back to image
        generated_img = self.decoder.decode(target_features)
        return generated_img

    def transform_recons(self, img):
        # encode image
        #img2 = deconv_ir(img2, strides=[1, 2, 2, 1], scope_name='deconv_ir')
        #img1 = deconv_vis(img1, strides=[1, 1, 1, 1], scope_name='deconv_vis')
        #img = tf.concat([img1, img2], 0)
        enc1, enc2, enc3 = self.encoder.encode(img)
        enc = tf.concat([enc1, enc2], 3)
        enc = tf.concat([enc, enc3], 3)
        target_features = enc
        self.target_features = target_features
        generated_img = self.decoder.decode(target_features)
        return generated_img


    def transform_concat(self, img1,img2):
        img = img1 + img2
        target_features = img
        self.target_features = target_features
        generated_img = self.decoder.decode(target_features)
        return generated_img

    def transform_encoder(self, img):
        # encode image
        enc = self.encoder.encode(img)
        return enc

    def transform_decoder(self, feature):
        # decode image
        generated_img = self.decoder.decode(feature)
        return generated_img

