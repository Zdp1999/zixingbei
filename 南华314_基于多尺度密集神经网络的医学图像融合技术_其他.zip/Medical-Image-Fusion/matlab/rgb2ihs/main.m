clc;
clear all;
for num=1:2
  I_ir=im2double(imread(strcat('./1/',num2str(num),'.tif')));  
  [I,v1,v2]=rgb2ihs(I_ir); 
  imwrite(I, strcat('./I/',num2str(num),'.tif'));
  imwrite(v1, strcat('./S/',num2str(num),'.tif'));
  imwrite(v2, strcat('./H/',num2str(num),'.tif'));
%   imwrite(v1,strcat('',num2str(num),'.bmp'));
%   imwrite(v2,strcat('',num2str(num),'.bmp'));
  
end